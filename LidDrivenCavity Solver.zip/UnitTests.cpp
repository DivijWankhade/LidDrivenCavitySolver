#include <iostream>
#include <algorithm>
#include <cstring>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <mpi.h>
using namespace std;

#include <cblas.h>
#include "LidDrivenCavity.h"
#include "SolverCG.h"


#define BOOST_TEST_MODULE SolverCG
#include <boost/test/included/unit_test.hpp>

#define IDX(I,J) ((J)*Nx + (I))
#define IDXloc(I,J) ((J)*Nx_local + (I))

struct MPIFixture {
    public:
        explicit MPIFixture() {
            argc = boost::unit_test::framework::master_test_suite().argc;
            argv = boost::unit_test::framework::master_test_suite().argv;
            cout << "Initialising MPI" << endl;
            MPI_Init(&argc, &argv);
        }

        ~MPIFixture() {
            cout << "Finalising MPI" << endl;
            MPI_Finalize();
        }

        int argc;
        char **argv;
};
BOOST_GLOBAL_FIXTURE(MPIFixture);

// Define the struct here
struct LidDrivenCavityTestAccessor {
    static double* GetVNew(LidDrivenCavity& LidDrivenCavityUnitTest) {
        return LidDrivenCavityUnitTest.vnew;
    }
};

BOOST_AUTO_TEST_CASE( SolverCG_Accuracy ){

    /** Sinusoidal test case with analytical solution, which can be used to test the Poisson solver 
     *  Computations below creates v of the form (18*pi^2*sin(3pix)sin(3piy))
     *  By simple hand calculations s can be calculated to be sin(3pix)sin(3piy)
     * */ 
    
    const double k = 3.0; //Represents frequency of sinusoidal function
    const double l = 3.0;
    const int Nx = 501;
    const int Ny = 501;
    const int Npts = Nx*Ny;
    double dx = 1.0/(Nx-1);
    double dy = 1.0/(Ny-1);

    double Tol = 1/10.0/10.0/10.0/10.0 * Npts;   //If all points have an error of order 10^-4
    double error;
    double error_global;
    
    double* v   = new double[Npts];
    double* s   = new double[Npts];
    double* ExactSol = new double[Npts];
    
    
    for (int i = 0; i < Nx; ++i) {
        for (int j = 0; j < Ny; ++j) {
            v[IDX(i,j)] = M_PI * M_PI * (k * k + l * l) * sin(M_PI * k * i * dx) * sin(M_PI * l * j * dy);          //Generates v of aforedmentioned form
                                                    
            ExactSol[IDX(i,j)] = sin(M_PI * k * i * dx) * sin(M_PI * l * j * dy);       //Generates s of aforedmentioned form   

        }
    }
    
    int rank,size;
    //Retrieve rank and size
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    

    //Create Cartesian grid - Same implementation as in LidDrivenCavity
    MPI_Comm CompleteDomain;

    int p = int(sqrt(size));      
    
    int dims1 = 2;
    int sizes[dims1] = {p,p};
    int periods[dims1] = {0,0};
    int reorder = 1;
    
    MPI_Cart_create(MPI_COMM_WORLD,dims1,sizes,periods,reorder,&CompleteDomain);
    
    MPI_Comm RowCom, ColCom;
    int coords[dims1];
    int keep[dims1];
    
   
    int CompleteDomain_rank;
    
    MPI_Comm_rank(CompleteDomain,&CompleteDomain_rank);
  
    MPI_Cart_coords(CompleteDomain,CompleteDomain_rank,dims1,coords);
    
    keep[0] = 0;
    keep[1] = 1;
    MPI_Cart_sub(CompleteDomain,keep,&RowCom);
    
    keep[0] = 1;
    keep[1] = 0;
    MPI_Cart_sub(CompleteDomain,keep,&ColCom);
    
    

    //Fetches info about rank position in the cartesian grid
    int dims2[2], periods2[2], coords2[2];
    MPI_Cart_get(CompleteDomain,2,dims2,periods2,coords2);
    
    int rows_per_rank = Ny/p;
    int cols_per_rank = Nx/p;
    
    int extra_rows = Ny % p;
    int extra_cols = Nx % p;
    
    int Ny_local = rows_per_rank;
    int Nx_local = cols_per_rank;
    
    if(coords2[1] < extra_rows){
        Nx_local += 1;
    }

    if(coords2[0] < extra_cols){
        Ny_local += 1;
    }
    
    int Npts_local = Nx_local*Ny_local;
    
    //Initialise local variables
    double* v_local   = new double[Npts_local];
    double* s_local   = new double[Npts_local];
    double* ExactSol_local = new double[Npts_local];
    
    //Initialise solver instance
    SolverCG* cg  = new SolverCG(Nx_local, Ny_local, dx, dy,CompleteDomain,RowCom,ColCom);
    
    //Compute ranks position in global domain
    int* allNx_local = new int[size];
    int* allNy_local = new int[size];
    
    MPI_Allgather(&Nx_local, 1, MPI_INT, allNx_local, 1, MPI_INT, MPI_COMM_WORLD);
    MPI_Allgather(&Ny_local, 1, MPI_INT, allNy_local, 1, MPI_INT, MPI_COMM_WORLD);
    
    int I_start = 0;
    int J_start = 0;
    
    for (int i = 0; i < coords2[1]; i++) {
        I_start += allNx_local[coords2[0]*dims2[1] + i]; // Sum widths of all columns to the left
    }
    
    for (int aboveRow = dims2[0]-1; aboveRow > coords2[0]; --aboveRow) {
        int aboveRank = aboveRow * dims2[1] + coords2[1]; // Rank directly above in the same column
        J_start += allNy_local[aboveRank];
    }
    
    for (int j=0;j<Ny_local;j++){
        for (int i=0;i<Nx_local;i++){
            v_local[IDXloc(i,j)] = v[IDX(I_start+i,J_start+j)];
            ExactSol_local[IDXloc(i,j)] =  ExactSol[IDX(I_start+i,J_start+j)];

        }
    }
    
    // Solve Poisson problem
    cg->Solve(v_local, s_local);
    
    //Compute error 
    cblas_daxpy(Npts_local,-1, s_local, 1, ExactSol_local, 1); //ExactSol - s
    error = cblas_dnrm2(Npts_local, ExactSol_local, 1); 
    
    MPI_Allreduce(&error, &error_global, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    
    
    //cout<<"Error: "<<error_global<<endl;
    //Check if the error between the exact and numerical solution is small enough
    BOOST_CHECK( error_global < Tol );
    
    delete [] v;
    delete [] s;
    delete [] ExactSol;
    delete [] v_local;
    delete [] s_local;
    delete [] ExactSol_local;
    delete [] allNx_local;
    delete [] allNy_local;

    delete cg;
}

BOOST_AUTO_TEST_CASE( LidDrivenCavityAccuracy ){

    //Variables to store rank and size
    int rank,size,retval_rank,retval_size;

    //Retrieve rank and size
    retval_rank = MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    retval_size = MPI_Comm_size(MPI_COMM_WORLD, &size);



    //Create Cartesian grid
    MPI_Comm CompleteDomain;
    int p = int(sqrt(size));      
    
    const int dims = 2;
    int sizes[dims] = {p,p};
    int periods[dims] = {0,0};
    int reorder = 1;
    
    MPI_Cart_create(MPI_COMM_WORLD,dims,sizes,periods,reorder,&CompleteDomain);
    
    MPI_Comm RowCom, ColCom;
    int coords[dims];
    int keep[dims];
    
    int CompleteDomain_rank;
    MPI_Comm_rank(CompleteDomain,&CompleteDomain_rank);
    MPI_Cart_coords(CompleteDomain,CompleteDomain_rank,dims,coords);
    
    keep[0] = 0;
    keep[1] = 1;
    MPI_Cart_sub(CompleteDomain,keep,&RowCom);
    
    keep[0] = 1;
    keep[1] = 0;
    MPI_Cart_sub(CompleteDomain,keep,&ColCom);

    double Lx = 1.0;
    double Ly = 1.0;
    int Nx = 9;
    int Ny = 9;
    double dt = 0.01;
    double T = 0.01;
    double Re = 10.0;

    LidDrivenCavity* solver = new LidDrivenCavity();

    //Fetches info about the cartesian grid
    int dims2[2], periods2[2], coords2[2];
    MPI_Cart_get(CompleteDomain,2,dims2,periods2,coords2);

    int tot_cols = dims2[1];
    
    //Calculate local grid size
    int rows_per_rank = Ny/p;
    int cols_per_rank = Nx/p;
    
    int extra_rows = Ny % p;
    int extra_cols = Nx % p;
    
    int Ny_local = rows_per_rank;
    int Nx_local = cols_per_rank;
    
    if(coords2[1] < extra_rows){
        Ny_local += 1;
    }

    if(coords2[0] < extra_cols){
        Nx_local += 1;
    }

    solver->SetDomainSize(Lx,Ly);
    solver->SetGridSize(Nx_local,Ny_local);
    solver->SetTimeStep(dt);
    solver->SetFinalTime(T);
    solver->SetReynoldsNumber(Re);

    solver->Initialise(CompleteDomain, RowCom, ColCom);

    solver->Integrate();
    
    //Obtain Vnew 
    double* vnewArray = LidDrivenCavityTestAccessor::GetVNew(*solver);
    
    for (int i=0;i<Nx_local;i++){
        for (int j=0;j<Ny_local;j++){
            
            //Top left Grid
            if (coords[0] == 0 && coords[1] == 0){
                
                //Left edge
                if(i==0){
                    BOOST_CHECK(vnewArray[IDXloc(i,j)] == 0.0);
                }
                else if(j==Ny_local-2){
                    BOOST_CHECK(vnewArray[IDXloc(i,j)] == -1.024);
                }
                else{
                    BOOST_CHECK(vnewArray[IDXloc(i,j)] == 0.0);
                }


            }

            //Top right Grid
            else if (coords[0] == 0 && coords[1] == tot_cols-1){

                //Right edge
                if(i==Nx_local-1){
                    BOOST_CHECK(vnewArray[IDXloc(i,j)] == 0.0);
                }
                else if(j==Ny_local-2){
                    BOOST_CHECK(vnewArray[IDXloc(i,j)] == -1.024);
                }
                else{
                    BOOST_CHECK(vnewArray[IDXloc(i,j)] == 0.0);
                }

            }

            //Top row in Grids, not in top left or top right
            else if (coords[0] == 0){
                
                //Second Row
                if (j==Ny_local-2){
                    BOOST_CHECK(vnewArray[IDXloc(i,j)] == -1.024);
                }

                else{
                    BOOST_CHECK(vnewArray[IDXloc(i,j)] == 0.0);
                }
            }

            //Rest of grid points
            else{
                BOOST_CHECK(vnewArray[IDXloc(i,j)] == 0.0);
            }

        
        }
    }

delete [] vnewArray;    
}    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
