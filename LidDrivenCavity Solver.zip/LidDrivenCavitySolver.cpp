#include <iostream>
#include <mpi.h>
#include <math.h>
using namespace std;

#include <boost/timer/timer.hpp>
#include <boost/program_options.hpp>
namespace po = boost::program_options;   //Boost utilised to allow users to specify simulation parameters in command line

#include "LidDrivenCavity.h"

int main(int argc, char *argv[])   
{
    //Variables to store rank and size
    int rank,size,retval_rank,retval_size;
    
    //Initialise MPI 
    int err = MPI_Init(&argc,&argv);
    if (err != MPI_SUCCESS) {
        cout << "Failed to initialise MPI" << endl;
        return -1;
    } 
    
    //Retrieve rank and size
    retval_rank = MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    retval_size = MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    
    //Check for valid communicator
    if (retval_rank == MPI_ERR_COMM || retval_size == MPI_ERR_COMM){
        cout<<"Invalid communicator"<<endl;
        return 1;
    }
    
    //Create Cartesian grid
    MPI_Comm CompleteDomain;
    
    //Size of each dimension of cartesian grid 
    int p = static_cast<int>(sqrt(size));

    //Ends program if size not a square number
    if (p*p != size){
        if (rank == 0){
            cout<<"Number of processes should be a square number"<<endl;
        }
        return 1;
    }
    
    //Cartesian Topology Parameters
    const int dims = 2;
    int sizes[dims] = {p,p};
    int periods[dims] = {0,0}; //Non periodic
    int reorder = 1;
    
    //Create Cartesian grid
    MPI_Cart_create(MPI_COMM_WORLD,dims,sizes,periods,reorder,&CompleteDomain);
    
    //Initialise communicators
    MPI_Comm RowCom, ColCom;
    int coords[dims];
    int keep[dims];
    
    int CompleteDomain_rank;
    MPI_Comm_rank(CompleteDomain,&CompleteDomain_rank);
    MPI_Cart_coords(CompleteDomain,CompleteDomain_rank,dims,coords);
    
    //Create Row communicator
    keep[0] = 0;
    keep[1] = 1;
    MPI_Cart_sub(CompleteDomain,keep,&RowCom);
    
    //Create column communicator 
    keep[0] = 1;
    keep[1] = 0;
    MPI_Cart_sub(CompleteDomain,keep,&ColCom);
    
    //Simulation Parameters
    double Lx, Ly, dt, T, Re;
    int Nx, Ny;
    
    //Rank 0 parses command line
    if (rank == 0){
    
        po::options_description opts("Solver for the 2D lid-driven cavity incompressible flow problem");
        opts.add_options()
            ("Lx",  po::value<double>()->default_value(1.0),
                     "Length of the domain in the x-direction.")
            ("Ly",  po::value<double>()->default_value(1.0),
                     "Length of the domain in the y-direction.")
            ("Nx",  po::value<int>()->default_value(151),
                     "Number of grid points in x-direction.")
            ("Ny",  po::value<int>()->default_value(151),
                     "Number of grid points in y-direction.")
            ("dt",  po::value<double>()->default_value(0.005),
                     "Time step size.")
            ("T",   po::value<double>()->default_value(50.0),
                     "Final time.")
            ("Re",  po::value<double>()->default_value(1000),
                     "Reynolds number.")
            ("verbose",    "Be more verbose.")
            ("help",       "Print help message.");

        po::variables_map vm; //Stores parsed variables in map
        po::store(po::parse_command_line(argc, argv, opts), vm);
        po::notify(vm);

        if (vm.count("help")) {
            cout << opts << endl;
            return 0;
        }
        
        Lx = vm["Lx"].as<double>();
        Ly = vm["Ly"].as<double>();
        Nx = vm["Nx"].as<int>();
        Ny = vm["Ny"].as<int>();
        dt = vm["dt"].as<double>();
        T = vm["T"].as<double>();
        Re = vm["Re"].as<double>();
    }

    

    //Send command line parsed data from rank 0 to all ranks
    MPI_Bcast(&Lx, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&Ly, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&Nx, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&Ny, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dt, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&T, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&Re, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    
    //Instance created of LidDrivenCavity with entered parameters
    LidDrivenCavity* solver = new LidDrivenCavity();

    //Find the local number of Nx and Ny points each rank has to handle
    int rows_per_rank = Ny/p;
    int cols_per_rank = Nx/p;
    
    int extra_rows = Ny % p;
    int extra_cols = Nx % p;
    
    int Ny_local = rows_per_rank;
    int Nx_local = cols_per_rank;
    
    if(coords[1] < extra_rows){
        Nx_local += 1;
    }

    if(coords[0] < extra_cols){
        Ny_local += 1;
    }

    //Update parameters
    solver->SetDomainSize(Lx,Ly);
    solver->SetGridSize(Nx_local,Ny_local);
    solver->SetTimeStep(dt);
    solver->SetFinalTime(T);
    solver->SetReynoldsNumber(Re);

    if (rank==0){
       solver->PrintConfiguration(); //Current setup 
    }
    
    //Intialise solver instance and pass in communicators
    solver->Initialise(CompleteDomain, RowCom, ColCom);

    
    solver->WriteSolution("ic.txt"); //Inital states 
    
    
    boost::timer::cpu_timer timer; 
    
    MPI_Barrier(MPI_COMM_WORLD);
    if (rank == 0){
        
        timer.start(); //Starts timer
    }
    
    solver->Integrate(); 
    
    //All ranks must finish for timer to stop 
    MPI_Barrier(MPI_COMM_WORLD);
    
    if (rank == 0){
        timer.stop(); //Stop timer
        
        boost::timer::cpu_times elapsed = timer.elapsed();
        
        double wallTime = elapsed.wall / 1e9; // Convert nanoseconds to seconds
        double userTime = elapsed.user / 1e9;
        double systemTime = elapsed.system / 1e9;

        cout << "Time Taken: " << wallTime << "s wall\n";
        cout << "User CPU Time: " << userTime << "s\n";
        cout << "System CPU Time: " << systemTime << "s\n";
        
    }
    
    solver->WriteSolution("final.txt"); //Final states    
    
    MPI_Finalize();
    
	return 0;
}
