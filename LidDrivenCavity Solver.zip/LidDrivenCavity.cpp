#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cmath>
using namespace std;

#include <mpi.h>
#include <cblas.h>
#include <boost/timer/timer.hpp>
#include <omp.h>

#define IDX(I,J) ((J)*Nx + (I))

#include "LidDrivenCavity.h"
#include "SolverCG.h"

LidDrivenCavity::LidDrivenCavity()  //Initialises sim with default parameters
{
}

LidDrivenCavity::~LidDrivenCavity()  //Deallocated dynamically allocated memory
{
    CleanUp();
}

void LidDrivenCavity::SetDomainSize(double xlen, double ylen) //Configures physical parameters of domain
{
    this->Lx = xlen;
    this->Ly = ylen;
    UpdateDxDy();
}

void LidDrivenCavity::SetGridSize(int nx, int ny)
{
    this->Nx = nx;
    this->Ny = ny;
    //UpdateDxDy();
}

void LidDrivenCavity::SetTimeStep(double deltat)
{
    this->dt = deltat;
}

void LidDrivenCavity::SetFinalTime(double finalt)
{
    this->T = finalt;
}

void LidDrivenCavity::SetReynoldsNumber(double re)
{
    this->Re = re;
    this->nu = 1.0/re;
}

void LidDrivenCavity::Initialise(MPI_Comm domainComm, MPI_Comm rowComm, MPI_Comm colComm)    //Allocates temprorary memory for vorticity, stream function and a temporary helper array
{
    CleanUp();
    
    Npts = Nx*Ny;
    
    v   = new double[Npts]();
    vnew = new double[Npts]();
    s   = new double[Npts]();
    tmp = new double[Npts]();
    cg  = new SolverCG(Nx, Ny, dx, dy,domainComm,rowComm,colComm);     //Initialises SolverCG for solving CG object
    
    CompleteDomain = domainComm;
    RowCom = rowComm;
    ColCom = colComm;
    
}

void LidDrivenCavity::Integrate() //Advances simulation over time
{
    int NSteps = ceil(T/dt);
    
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    
    //for (int t = 0; t < NSteps; ++t)
    for (int t = 0; t < NSteps; ++t)
    {
        if (rank==0){
            std::cout << "Step: " << setw(8) << t
                  << "  Time: " << setw(8) << t*dt
                  << std::endl;
        }
        
        Advance();
    }


    
}

void LidDrivenCavity::WriteSolution(std::string file) //Outputs current state to a txt file 
{
    double* u0 = new double[Nx*Ny]();
    double* u1 = new double[Nx*Ny]();
    
    int Nx_local = Nx;
    int Ny_local = Ny;

    
    //Fetches info about the cartesian grid - Same implementation as Advance
    int dims[2], periods[2], coords[2];
    MPI_Cart_get(CompleteDomain,2,dims,periods,coords);
    
    int tot_rows = dims[0];
    int tot_cols = dims[1];
    
    int rank,size;
    MPI_Comm_rank(CompleteDomain, &rank);
    MPI_Comm_size(CompleteDomain, &size);
    
    int left_rank,right_rank,up_rank,down_rank;
    
    MPI_Cart_shift(RowCom, 0, 1, &left_rank, &right_rank);
    MPI_Cart_shift(ColCom, 1, 1, &up_rank, &down_rank);
    
    
    double* temp_send_down = nullptr;
    double* temp_send_left = nullptr;
    
    double* temp_recv_right = nullptr;
    double* temp_recv_up = nullptr;
    
    if (left_rank != MPI_PROC_NULL) {
  
        temp_send_left = new double[Ny_local];

        for (int j = 0; j < Ny_local; j++) {
            temp_send_left[j] = s[IDX(0, j)];
        }
        
        MPI_Send(temp_send_left, Ny_local, MPI_DOUBLE, left_rank, 0, RowCom);
    }
    
    if (right_rank != MPI_PROC_NULL) {
        temp_recv_right = new double[Ny_local];

        MPI_Recv(temp_recv_right, Ny_local, MPI_DOUBLE, right_rank, 0, RowCom, MPI_STATUS_IGNORE);
    }
    
    if (down_rank != MPI_PROC_NULL) {
  
        temp_send_down = new double[Nx_local];

        for (int i = 0; i < Nx_local; i++) {
            temp_send_down[i] = s[IDX(i, 0)];
        }
        
        MPI_Send(temp_send_down, Nx_local, MPI_DOUBLE, down_rank, 0, ColCom);
    }
    
    if (up_rank != MPI_PROC_NULL) {
        temp_recv_up = new double[Nx_local];

        MPI_Recv(temp_recv_up, Nx_local, MPI_DOUBLE, up_rank, 0, ColCom, MPI_STATUS_IGNORE);
    }
    
    //Interior index limits (miss out edges) 
    int start_i = coords[1] == 0 ? 1 : 0;      //Left edge
    int end_i = Nx_local - (coords[1] == tot_cols - 1 ? 1 : 0); //Right edge
    
    int start_j = coords[0] == tot_rows - 1 ? 1 : 0;   //Bottom edge 
    int end_j = Ny_local - (coords[0] == 0 ? 1 : 0);  //Top edge

    
    for (int j = start_j; j < end_j; j++) {
        for (int i = start_i; i < end_i; i++) {
            //See if adjacent points are out of bounds, if so IDX(x,y) assigned -1
            
            int right = i < Nx_local - 1 ? IDX(i+1, j) : -1;
            int top = j < Ny_local - 1 ? IDX(i, j+1) : -1;
            
            //If adjacent points out of bounds, then data sent across boundary used
            double s_right, s_top;
            
            s_right = (right != -1) ? s[right] : temp_recv_right[j];
            s_top = (top != -1) ? s[top] : temp_recv_up[i];

            //Compute velocities
            u0[IDX(i,j)] =  (s_top - s[IDX(i,j)]) / dy;
            u1[IDX(i,j)] = -(s_right - s[IDX(i,j)]) / dx;
        }
    }
    
    //Upper surface velocity 
    if (coords[0] == 0){
        for (int i = 0; i < Nx_local;i++){
            u0[IDX(i,Ny_local-1)] = U;
        }
    }
       
    //Arrays to store local sizes of each rank
    int* allNx_local = new int[size];
    int* allNy_local = new int[size];
    
    MPI_Allgather(&Nx_local, 1, MPI_INT, allNx_local, 1, MPI_INT, MPI_COMM_WORLD);
    MPI_Allgather(&Ny_local, 1, MPI_INT, allNy_local, 1, MPI_INT, MPI_COMM_WORLD);
    
    // Calculate start indices
    int I_start = 0;
    int J_start = 0;
    
    //Calculate postions in global domain
    for (int i = 0; i < coords[1]; i++) {
        I_start += allNx_local[coords[0]*dims[1] + i]; // Sum widths of all columns to the left
    }
    
    for (int aboveRow = dims[0]-1; aboveRow > coords[0]; --aboveRow) {
        int aboveRank = aboveRow * dims[1] + coords[1]; // Rank directly above in the same column
        J_start += allNy_local[aboveRank];
    }   
    

    if (rank == 0){
        std::cout << "Writing file " << file << std::endl;
    }
   
    int k = 0;
    
    //Each rank writes to the text file in turn
    if (rank == 0){
        
        std::ofstream f(file.c_str(), std::ios::out);
        for (int j=0;j<Ny_local;j++){
            for (int i=0;i<Nx_local;i++){
                
                k = IDX(i,j);
                
                f << (I_start+i) * dx << " " << (J_start + j)* dy << " " << v[k] << " " << s[k] << " " << u0[k] << " " << u1[k] << std::endl;
            }
            f << std::endl;
        }
        f.close();
        
        if (size > 1) {
            MPI_Send(nullptr, 0, MPI_BYTE, 1, 0, MPI_COMM_WORLD); // Signal next process
        }
    }
    
    else{
        
        MPI_Status status;
        MPI_Recv(nullptr, 0, MPI_BYTE, rank - 1, 0, MPI_COMM_WORLD, &status);
        
        std::ofstream f(file.c_str(), std::ios::app);
        
        for (int j=0;j<Ny_local;j++){
            for (int i=0;i<Nx_local;i++){
                
                k = IDX(i,j);
                
                f << (I_start+i) * dx << " " << (J_start+j) * dy << " " << v[k] << " " << s[k] << " " << u0[k] << " " << u1[k] << std::endl;
            }
            f << std::endl;
        }
        f.close();
        if (rank + 1 < size) {
            MPI_Send(nullptr, 0, MPI_BYTE, rank + 1, 0, MPI_COMM_WORLD); // Signal next process
        }
    }
    
    //Deallocate arrays 
    delete[] u0;
    delete[] u1;
    
    delete[] temp_send_left;
    delete[] temp_send_down;
    
    delete[] temp_recv_right;
    delete[] temp_recv_up;
    
    delete[] allNx_local;
    delete[] allNy_local;
}


void LidDrivenCavity::PrintConfiguration()  //Outputs simulation parameters
{
    cout << "Grid size: " << Nx << " x " << Ny << endl;
    cout << "Spacing:   " << dx << " x " << dy << endl;
    cout << "Length:    " << Lx << " x " << Ly << endl;
    cout << "Grid pts:  " << Npts << endl;
    cout << "Timestep:  " << dt << endl;
    cout << "Steps:     " << ceil(T/dt) << endl;
    cout << "Reynolds number: " << Re << endl;
    cout << "Linear solver: preconditioned conjugate gradient" << endl;
    cout << endl;
    if (nu * dt / dx / dy > 0.25) {
        cout << "ERROR: Time-step restriction not satisfied!" << endl;
        cout << "Maximum time-step is " << 0.25 * dx * dy / nu << endl;
        exit(-1);
    }
}


void LidDrivenCavity::CleanUp()  //Deallocates dynamic memory
{
    if (v) {
        delete[] v;
        delete[] vnew;
        delete[] s;
        delete[] tmp;
        delete cg;
    }
}


void LidDrivenCavity::UpdateDxDy()  //Updating grid spacing
{
    dx = Lx / (Nx-1);
    dy = Ly / (Ny-1);
    Npts = Nx * Ny;
}


void LidDrivenCavity::Advance()  //Advancing solution to next time step
    {
    //Helpful comments
    double dxi  = 1.0/dx;
    double dyi  = 1.0/dy;
    double dx2i = 1.0/dx/dx;
    double dy2i = 1.0/dy/dy;
    
    //Local domain sizes
    int Nx_local = Nx;
    int Ny_local = Ny;
    
    //Fetches info about the cartesian grid
    int dims[2], periods[2], coords[2];
    MPI_Cart_get(CompleteDomain,2,dims,periods,coords);
    
    //Fetches total rows and columns
    int tot_rows = dims[0];
    int tot_cols = dims[1];
    
    //Find which subgrids are neighbours
    int left_rank,right_rank,up_rank,down_rank;
    
    MPI_Cart_shift(RowCom, 0, 1, &left_rank, &right_rank); //Left and right neighbours
    MPI_Cart_shift(ColCom, 1, 1, &up_rank, &down_rank); //Above and below neighbours
    
    
    //Calculating vorticity at boundary locations
    int start_i;
    int start_j;
    int end_i;
    int end_j;
     
    int i,j;
    
    if (coords[0] == 0){     //Top row
        if (coords[1] == 0){
            start_i = 1;
            end_i = Nx_local;
        }
        else if (coords[1] == tot_cols - 1){
            start_i = 0;
            end_i = Nx_local - 1;
        }
        else{
            start_i = 0;
            end_i = Nx_local;
        }
        
        //Apply top boundary condition 
        #pragma omp parallel for default(shared) private(i) schedule(guided)   
        for (i=start_i;i<end_i;i++)
            {
            v[IDX(i,Ny_local-1)] = 2.0 * dy2i * (s[IDX(i,Ny_local-1)] - s[IDX(i,Ny_local-2)])
                       - 2.0 * dyi*U;
            }
        
    }
    
    if (coords[0] == tot_rows-1){     //Bottom row
        if (coords[1] == 0){
            start_i = 1;
            end_i = Nx_local;
        }
        else if (coords[1] == tot_cols - 1){
            start_i = 0;
            end_i = Nx_local - 1;
        }
        else{
            start_i = 0;
            end_i = Nx_local;
        }
        
        //Apply bottom boundary condition 
        #pragma omp parallel for default(shared) private(i) schedule(guided)   
        for (i=start_i;i<end_i;i++)
            {
            v[IDX(i,0)]    = 2.0 * dy2i * (s[IDX(i,0)]    - s[IDX(i,1)]);
            }
        
    }
    
    if (coords[1] == 0){     //Left column
        if (coords[0] == 0){
            start_j = 0;
            end_j = Ny_local-1;
        }
        else if (coords[0] == tot_rows-1){
            start_j = 1;
            end_j = Ny_local ;
        }
        else{
            start_j = 0;
            end_j = Ny_local;
        }
        
        //Apply left boundary condition
        #pragma omp parallel for default(shared) private(j) schedule(guided)   
        for (j=start_j;j<end_j;j++)
            {
            v[IDX(0,j)] = 2.0 * dx2i * (s[IDX(0,j)]    - s[IDX(1,j)]);
            }
    }
    
    if (coords[1] == tot_cols - 1){     //Right column
        if (coords[0] == 0){
            start_j = 0;
            end_j = Ny_local-1;
        }
        else if (coords[0] == tot_rows-1){
            start_j = 1;
            end_j = Ny_local ;
        }
        else{
            start_j = 0;
            end_j = Ny_local;
        }
        
        //Apply right boundary condition
        #pragma omp parallel for default(shared) private(j) schedule(guided)   
        for (j=start_j;j<end_j;j++)
            {
            v[IDX(Nx_local-1,j)] = 2.0 * dx2i * (s[IDX(Nx_local-1,j)] - s[IDX(Nx_local-2,j)]);
            }
    }
    
    //Need to send and receive arrays from boundaries
    
    //Temprorary arrays to store data sent between subgrids (For Stream Function)
    double* temp_send_left = nullptr;
    double* temp_send_right = nullptr;
    double* temp_send_up = nullptr;
    double* temp_send_down = nullptr;
    
    double* temp_recv_left = nullptr;
    double* temp_recv_right = nullptr;
    double* temp_recv_up = nullptr;
    double* temp_recv_down = nullptr;
    
    //For vorticity
    double* temp_send_left2 = nullptr;
    double* temp_send_right2 = nullptr;
    double* temp_send_up2 = nullptr;
    double* temp_send_down2 = nullptr;
    
    double* temp_recv_left2 = nullptr;
    double* temp_recv_right2 = nullptr;
    double* temp_recv_up2 = nullptr;
    double* temp_recv_down2 = nullptr;
    
    
    /**There are 9 unique locations of subgrid which require different communicators to send and receive from:
     * No   Location            Comms needed
     * 1)   TL (Top Left)       right,bottom
     * 2)   TM (Top Middle)     left,right,bottom
     * 3)   TR (Top Right)      left,bottom
     * 4)   ML (Middle Left)    right,top,bottom
     * 5)   MM (Middle Middle)  left,right,top,bottom
     * 6)   MR (Middle Right)   left,top,bottom
     * 7)   BL (Bottom Left)    top,right
     * 8)   BM (Bottom Middle)  left,right,top
     * 9)   BR (Bottom Right)   left,top
    **/
    
    //Left boundary exhange
    if (left_rank != MPI_PROC_NULL) {
        temp_send_left = new double[Ny_local];
        temp_recv_left = new double[Ny_local];
        
        temp_send_left2 = new double[Ny_local];
        temp_recv_left2 = new double[Ny_local];
    
        #pragma omp parallel for default(shared) private(j) schedule(guided)
        for (j = 0; j < Ny_local; j++) 
            {
            temp_send_left[j] = s[IDX(0, j)];
            temp_send_left2[j] = v[IDX(0, j)];
            }
        
        MPI_Sendrecv(temp_send_left, Ny_local, MPI_DOUBLE, left_rank, 0,
                 temp_recv_left, Ny_local, MPI_DOUBLE, left_rank, 0,
                 RowCom, MPI_STATUS_IGNORE);

        MPI_Sendrecv(temp_send_left2, Ny_local, MPI_DOUBLE, left_rank, 0,
                 temp_recv_left2, Ny_local, MPI_DOUBLE, left_rank, 0,
                 RowCom, MPI_STATUS_IGNORE);
    }

    //right boundary exchange
    if (right_rank != MPI_PROC_NULL) {
        temp_send_right = new double[Ny_local];
        temp_recv_right = new double[Ny_local];
        
        temp_send_right2 = new double[Ny_local];
        temp_recv_right2 = new double[Ny_local];

        #pragma omp parallel for default(shared) private(j) schedule(guided)
        for (j = 0; j < Ny_local; j++) 
            {
            temp_send_right[j] = s[IDX(Nx_local-1, j)];
            temp_send_right2[j] = v[IDX(Nx_local-1, j)];
            }
        
        MPI_Sendrecv(temp_send_right, Ny_local, MPI_DOUBLE, right_rank, 0,
                 temp_recv_right, Ny_local, MPI_DOUBLE, right_rank, 0,
                 RowCom, MPI_STATUS_IGNORE);

        MPI_Sendrecv(temp_send_right2, Ny_local, MPI_DOUBLE, right_rank, 0,
                 temp_recv_right2, Ny_local, MPI_DOUBLE, right_rank, 0,
                 RowCom, MPI_STATUS_IGNORE);
    }

    //bottom boundary exchange
    if (down_rank != MPI_PROC_NULL) {
        temp_send_down = new double[Nx_local];
        temp_recv_down = new double[Nx_local];
        
        temp_send_down2 = new double[Nx_local];
        temp_recv_down2 = new double[Nx_local];

        #pragma omp parallel for default(shared) private(i) schedule(guided)
        for (i = 0; i < Nx_local; i++) 
            {
            temp_send_down[i] = s[IDX(i, 0)];
            temp_send_down2[i] = v[IDX(i, 0)];
            }

        MPI_Sendrecv(temp_send_down, Nx_local, MPI_DOUBLE, down_rank, 0,
                 temp_recv_down, Nx_local, MPI_DOUBLE, down_rank, 0,
                 ColCom, MPI_STATUS_IGNORE);

        MPI_Sendrecv(temp_send_down2, Nx_local, MPI_DOUBLE, down_rank, 0,
                 temp_recv_down2, Nx_local, MPI_DOUBLE, down_rank, 0,
                 ColCom, MPI_STATUS_IGNORE);

    }

    //Top boundary exchange
    if (up_rank != MPI_PROC_NULL) {
        temp_send_up = new double[Nx_local];
        temp_recv_up = new double[Nx_local];
        
        temp_send_up2 = new double[Nx_local];
        temp_recv_up2 = new double[Nx_local];

        #pragma omp parallel for default(shared) private(i) schedule(guided)
        for (i = 0; i < Nx_local; i++) 
            {
            temp_send_up[i] = s[IDX(i, Ny_local-1)];
            temp_send_up2[i] = v[IDX(i, Ny_local-1)];
            }
        
        MPI_Sendrecv(temp_send_up, Nx_local, MPI_DOUBLE, up_rank, 0,
                 temp_recv_up, Nx_local, MPI_DOUBLE, up_rank, 0,
                 ColCom, MPI_STATUS_IGNORE);

        MPI_Sendrecv(temp_send_up2, Nx_local, MPI_DOUBLE, up_rank, 0,
                 temp_recv_up2, Nx_local, MPI_DOUBLE, up_rank, 0,
                 ColCom, MPI_STATUS_IGNORE);

    }
    
    
    //Index limits for interior vorticity different depending on if gridpoint at edge:
    
    
    //Interior index limits (miss out edges) 
    start_i = coords[1] == 0 ? 1 : 0;      //Left edge
    end_i = Nx_local - (coords[1] == tot_cols - 1 ? 1 : 0); //Right edge
    
    start_j = coords[0] == tot_rows - 1 ? 1 : 0;   //Bottom edge 
    end_j = Ny_local - (coords[0] == 0 ? 1 : 0);  //Top edge
    
    //Allows nested loop to utilise threads more efficiently
    omp_set_max_active_levels(2);
    
    int left, right, top, bottom;
    double s_left, s_right, s_top, s_bottom;
    
    //Compute Interior  Points
    #pragma omp parallel for collapse(2) default(shared) \
    private(i, j, left, right, top, bottom, s_left, s_right, s_top, s_bottom) \
    schedule(guided) 
    for (j = start_j; j < end_j; j++) {
        for (i = start_i; i < end_i; i++) {
            //See if adjacent points are out of bounds, if so IDX(x,y) assigned -1
            
            left = i > 0 ? IDX(i-1, j) : -1;
            right = i < Nx_local - 1 ? IDX(i+1, j) : -1;
            top = j < Ny_local - 1 ? IDX(i, j+1) : -1;
            bottom = j > 0 ? IDX(i, j-1) : -1;
            
            //If adjacent points out of bounds, then data sent across boundary used
            
            s_left = (left != -1) ? s[left] : temp_recv_left[j];
            s_right = (right != -1) ? s[right] : temp_recv_right[j];
            
            s_top = (top != -1) ? s[top] : temp_recv_up[i];
            s_bottom = (bottom != -1) ? s[bottom] : temp_recv_down[i];
            
            //Compute interior vorticity
            v[IDX(i,j)] = dx2i*(
                    2.0 * s[IDX(i,j)] - s_right - s_left)
                        +dy2i*(
                    2.0 * s[IDX(i,j)] - s_top - s_bottom);
            
        }
    }
    
    double v_left, v_right, v_top, v_bottom;
    
    //Time advance voriticity
    #pragma omp parallel for collapse(2) default(shared) \
    private(i, j, left, right, top, bottom, s_left, s_right, s_top, s_bottom,v_left,v_right,v_top,v_bottom) \
    schedule(guided) 
    for (j = start_j; j < end_j; j++) {
        for (i = start_i; i < end_i; i++) {
            //See if adjacent points are out of bounds, if so IDX(x,y) assigned -1
            
            left = i > 0 ? IDX(i-1, j) : -1;
            right = i < Nx_local - 1 ? IDX(i+1, j) : -1;
            top = j < Ny_local - 1 ? IDX(i, j+1) : -1;
            bottom = j > 0 ? IDX(i, j-1) : -1;
            
            //If adjacent points out of bounds, then data sent across boundary used

            s_left = (left != -1) ? s[left] : temp_recv_left[j];
            s_right = (right != -1) ? s[right] : temp_recv_right[j];
            
            s_top = (top != -1) ? s[top] : temp_recv_up[i];
            s_bottom = (bottom != -1) ? s[bottom] : temp_recv_down[i];
            
            v_left = (left != -1) ? v[left] : temp_recv_left2[j];
            v_right = (right != -1) ? v[right] : temp_recv_right2[j];
            
            v_top = (top != -1) ? v[top] : temp_recv_up2[i];
            v_bottom = (bottom != -1) ? v[bottom] : temp_recv_down2[i];
            
            //Compute interior vorticity
            vnew[IDX(i,j)] = v[IDX(i,j)] + dt*(
                ( (s_right - s_left) * 0.5 * dxi
                 *(v_top - v_bottom) * 0.5 * dyi)
              - ( (s_top - s_bottom) * 0.5 * dyi
                 *(v_right - v_left) * 0.5 * dxi)
              + nu * (v_right - 2.0 * v[IDX(i,j)] + v_left)*dx2i
              + nu * (v_top - 2.0 * v[IDX(i,j)] + v_bottom)*dy2i);
            
        }
    }
   
    //Deallocate memory
    delete[] temp_send_left;
    delete[] temp_send_right;
    delete[] temp_send_up;
    delete[] temp_send_down;
    
    delete[] temp_send_left2;
    delete[] temp_send_right2;
    delete[] temp_send_up2;
    delete[] temp_send_down2;
    
    delete[] temp_recv_left;
    delete[] temp_recv_right;
    delete[] temp_recv_up;
    delete[] temp_recv_down;
    
    delete[] temp_recv_left2;
    delete[] temp_recv_right2;
    delete[] temp_recv_up2;
    delete[] temp_recv_down2; 
    
    // Solve Poisson problem
    cg->Solve(vnew, s);
}
