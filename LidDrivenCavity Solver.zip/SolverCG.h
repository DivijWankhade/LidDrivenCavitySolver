#pragma once

#include <mpi.h>

class SolverCG
/**
 * @class SolverCG
 * @brief Solves the poisson equation generated at each time step to compute stream function of next time step using complex conjugate method
 */
{
public:
    /** Constructor
     * @param pNx number of x points
     * @param pNy number of y points
     * @param pdx x discretisation
     * @param pdy y discretisation
     */
    SolverCG(int pNx, int pNy, double pdx, double pdy, MPI_Comm domainComm, MPI_Comm rowComm, MPI_Comm colComm);
    ///Clean up and deallocate memory
    ~SolverCG();
    
    /** Implements complex conjugate method
     * @param b vorticity of each point stored in an array
     * @param x on entry the stream function of the current time step, on exit the stream function of the next time step
     */
    void Solve(double* b, double* x);
    /** Implements equivalent of cblas_dnrm2
     * @param n size of array
     * @param x input array
     * @param incx increment of x
     */
    double Parallel_dnrm2(int n, double *x, int incx) ;
    /** Implements equivalent of cblas_ddot
     * @param n size of array
     * @param x input array
     * @param incx increment of x
     * @param y input array
     * @param incy increment of y 
     */
    
    double Parallel_ddot(int n, double *x, int incx, double *y, int incy);
     /** Implements equivalent of cblas_dcopy
     * @param n size of array
     * @param x input array
     * @param incx increment of x
     * @param y input array
     * @param incy increment of y 
     */
    void Parallel_dcopy(int n, double *x, int incx, double *y, int incy);
     /** Implements equivalent of cblas_ddot2
     * @param n size of array
     * @param alpha constant
     * @param x input array
     * @param incx x increment
     * @param y input array
     * @param incy y increment
     */
    
    void Parallel_daxpy(int n, double alpha, double *x, int incx, double *y, int incy);

private:
    double dx; ///x discretisation
    double dy; ///y discretisation
    int Nx; ///number of x gridpoints
    int Ny; ///number of y gridpoints
    double* r; ///arrays to help implement complex conjugate method
    double* p;
    double* z;
    double* t;
    
    MPI_Comm CompleteDomain, RowCom, ColCom;

    /** Evaluates poisson equation
     * @param p variable on RHS of poisson
     * @param variable on LHS of poisson
     */
    void ApplyOperator(double* p, double* t);
    
    /** Preconditions r after beta_k calculated to convverge to solution quicker
     * @param p r before preconditons
     * @param t r after precondition
     */
    void Precondition(double* p, double* t);
    
    /** Imposes no slip BC
     * @param p 
     */
    void ImposeBC(double* p);

};

