#pragma once

#include <string>
#include <mpi.h>
using namespace std;

class SolverCG;

/**
 * @class LidDrivenCavity
 * @brief Configures parameters of lid driven cavity, calculates vorticity at time step n and n+1 over whole domain
 */
class LidDrivenCavity
{
public:
    ///Default constructor 
    LidDrivenCavity();
    ///Clean up and deallocate memory
    ~LidDrivenCavity();

    /**
     * @param xlen length of x dimension
     * @param ylen length of y dimension
     */
    void SetDomainSize(double xlen, double ylen);
    /**
     * @param nx number of x points
     * @param ny number of y points
     */
    void SetGridSize(int nx, int ny);
    /**
     * @param deltat time step
     */
    void SetTimeStep(double deltat);
    /**
     * @param finalt final time period
     */
    void SetFinalTime(double finalt);
    /**
     * @param Re Reynolds number
     */
    void SetReynoldsNumber(double Re);

    ///Initialise memory for v,s,tmp,cg
    void Initialise(MPI_Comm domainComm, MPI_Comm rowComm, MPI_Comm colComm);
    ///Advances integration over time period
    void Integrate();
    ///Outputs v,s,u_velocity,v_velocity  
    void WriteSolution(std::string file);
    ///Outputs parameter values
    void PrintConfiguration();
    ///For use of LidDrivenCavity unit test case
    friend struct LidDrivenCavityTestAccessor; 

private:
    double* v   = nullptr; ///vorticity
    double* vnew = nullptr;
    double* s   = nullptr; ///stream function
    double* tmp = nullptr;

    double dt   = 0.01; ///time step
    double T    = 1.0;  ///time period
    //double T    = 0.01;  ///time period
    double dx; ///x discretisation
    double dy; ///y discretisation
    int    Nx   = 9; ///number of x gridpoints
    int    Ny   = 9; ///number of y gridpoints
    int    Npts = 81; ///total number of points
    double Lx   = 1.0; ///x length 
    double Ly   = 1.0; ///y length
    double Re   = 10; ///Reynolds number
    double U    = 1.0; ///Top surface BC
    double nu   = 0.1; /// \f$1/U\f$
    
    MPI_Comm CompleteDomain, RowCom, ColCom; ///Cartesain Grid Communicators

    SolverCG* cg = nullptr;
    
    ///Memory deallocation
    void CleanUp(); 
    
    ///Recalculate discretisation
    void UpdateDxDy(); 
    
    ///Calculates vorticity over whole domain
    void Advance(); 
};

