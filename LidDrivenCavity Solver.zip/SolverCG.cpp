#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;

#include <cblas.h>
#include <mpi.h>
#include <omp.h>

#include "SolverCG.h"

#define IDX(I,J) ((J)*Nx + (I))

SolverCG::SolverCG(int pNx, int pNy, double pdx, double pdy, MPI_Comm domainComm, MPI_Comm rowComm, MPI_Comm colComm) //Initialises variables and allocates memory
{
    dx = pdx;
    dy = pdy;
    Nx = pNx;     //Nx is now Nx_local
    Ny = pNy;
    int n = Nx*Ny;
    r = new double[n];
    p = new double[n];
    z = new double[n];
    t = new double[n]; //temp
    
    CompleteDomain = domainComm;
    RowCom = rowComm;
    ColCom = colComm;
}


SolverCG::~SolverCG()  //deallocates memory
{
    delete[] r;
    delete[] p;
    delete[] z;
    delete[] t;
}



double SolverCG::Parallel_dnrm2(int n, double *x, int incx) {
    
    double sum = 0.0;
    int i;

    #pragma omp parallel for default(shared) private(i) schedule(guided) reduction(+:sum)
    for (i = 0; i < n; i++) {
        sum += x[i * incx] * x[i * incx];
    }
    return sqrt(sum);
}


double SolverCG::Parallel_ddot(int n, double *x, int incx, double *y, int incy) {
    
    double sum = 0.0;
    int i;

    #pragma omp parallel for default(shared) private(i) schedule(guided) reduction(+:sum)
    for (i = 0; i < n; i++) {
        sum += x[i * incx] * y[i * incy];
    }
    return sum;
}

void SolverCG::Parallel_dcopy(int n, double *x, int incx, double *y, int incy) {
    
    int i;

    #pragma omp parallel for default(shared) private(i) schedule(guided)
    for (i = 0; i < n; i++) {
        y[i * incy] = x[i * incx];
    }
    
}

void SolverCG::Parallel_daxpy(int n, double alpha, double *x, int incx, double *y, int incy) {
    
    int i;

    #pragma omp parallel for default(shared) private(i) schedule(guided)
    for (i = 0; i < n; i++) {
        y[i * incy] += alpha * x[i * incx];
    }
    
}

//Conjugate gradient method (x = s from prev time step, b = v from current time step)
void SolverCG::Solve(double* b, double* x) {
    unsigned int n = Nx*Ny;
    int k;
    double alpha;
    double beta;
    double eps;
    double tol = 0.001;
    
    //global variables to be reduced on all ranks from their local counterparts
    double eps_global;
    double alpha_num_global,alpha_den_global,beta_num_global,beta_den_global;
    double alpha_global,beta_global;
    
    //Get rank 
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    eps = Parallel_dnrm2(n, b, 1);
    //Compute eps from all ranks
    MPI_Allreduce(&eps,&eps_global,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
    
    //Ends scheme
    if (eps_global < tol*tol) {
        std::fill(x, x+n, 0.0);
        if (rank == 0){
            cout << "Norm is " << eps_global << endl;
            
        }
        return;
    }

    ApplyOperator(x, t); //Implements eq 12 from brief
    
    Parallel_dcopy(n, b, 1, r, 1);        // r_0 = b (i.e. b)
    ImposeBC(r); //no slip at walls
    
    Parallel_daxpy(n, -1.0, t, 1, r, 1); //r_0 - b - Ax_0
    Precondition(r, z);
    
    Parallel_dcopy(n, z, 1, p, 1);        // p_0 = r_0

    k = 0;
    do {
        k++;
        // Perform action of Nabla^2 * p
        ApplyOperator(p, t);
        
        alpha = Parallel_ddot(n, t, 1, p, 1);  // alpha = p_k^T A p_k
        MPI_Allreduce(&alpha,&alpha_den_global,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD); 
        
        alpha = Parallel_ddot(n, r, 1, z, 1) ; // compute alpha_k
        MPI_Allreduce(&alpha,&alpha_num_global,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
        
        alpha_global = alpha_num_global/alpha_den_global;
        
        beta  = Parallel_ddot(n, r, 1, z, 1);  // z_k^T r_k
        MPI_Allreduce(&beta,&beta_den_global,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD); 

        Parallel_daxpy(n,  alpha_global, p, 1, x, 1);  // x_{k+1} = x_k + alpha_k p_k
        Parallel_daxpy(n, -alpha_global, t, 1, r, 1); // r_{k+1} = r_k - alpha_k A p_k

        eps = Parallel_dnrm2(n, r, 1);
        MPI_Allreduce(&eps,&eps_global,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);

        if (eps_global < tol*tol) {
            break;
        }
        Precondition(r, z); //Help converge in fewer iterations
        beta = Parallel_ddot(n, r, 1, z, 1);
        MPI_Allreduce(&beta,&beta_num_global,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
        
        beta_global = beta_num_global/beta_den_global;
        

        Parallel_dcopy(n, z, 1, t, 1);
        
        Parallel_daxpy(n, beta_global, p, 1, t, 1);
        
        Parallel_dcopy(n, t, 1, p, 1);

    } while (k < 5000); // Set a maximum number of iterations

    if (k == 5000) {
        if (rank == 0){
            cout << "FAILED TO CONVERGE" << endl;
        }
        
        exit(-1);
    }

    if (rank==0){
        cout << "Ranks have converged in " << k << " iterations. eps = " << eps_global << endl;
    }
    
}


void SolverCG::ApplyOperator(double* in, double* out) {
    
    int Nx_local = Nx;
    int Ny_local = Ny;
    
    
    int i,j;
    
    //Fetches info about the cartesian grid
    int dims[2], periods[2], coords[2];
    MPI_Cart_get(CompleteDomain,2,dims,periods,coords);
    
    int tot_rows = dims[0];
    int tot_cols = dims[1];
    
    //Find which subgrids are neighbours
    int left_rank,right_rank,up_rank,down_rank;
    MPI_Cart_shift(RowCom, 0, 1, &left_rank, &right_rank);
    MPI_Cart_shift(ColCom, 1, 1, &up_rank, &down_rank);
    
    //Temprorary arrays to store data sent between subgrids (For Stream Function)
    double* temp_send_left = nullptr;
    double* temp_send_right = nullptr;
    double* temp_send_up = nullptr;
    double* temp_send_down = nullptr;
    
    double* temp_recv_left = nullptr;
    double* temp_recv_right = nullptr;
    double* temp_recv_up = nullptr;
    double* temp_recv_down = nullptr;
    
    //Boundary communication 
    if (left_rank != MPI_PROC_NULL) {
        temp_send_left = new double[Ny_local];
        temp_recv_left = new double[Ny_local];
        
        #pragma omp parallel for default(shared) private(j) schedule(guided)
        for (j = 0; j < Ny_local; j++) {
            temp_send_left[j] = in[IDX(0, j)];
        }

        MPI_Sendrecv(temp_send_left, Ny_local, MPI_DOUBLE, left_rank, 0,
                 temp_recv_left, Ny_local, MPI_DOUBLE, left_rank, 0,
                 RowCom, MPI_STATUS_IGNORE);
    
    }

    if (right_rank != MPI_PROC_NULL) {
        temp_send_right = new double[Ny_local];
        temp_recv_right = new double[Ny_local];

        #pragma omp parallel for default(shared) private(j) schedule(guided)
        for (j = 0; j < Ny_local; j++) {
            temp_send_right[j] = in[IDX(Nx_local-1, j)];
        }

        MPI_Sendrecv(temp_send_right, Ny_local, MPI_DOUBLE, right_rank, 0,
                 temp_recv_right, Ny_local, MPI_DOUBLE, right_rank, 0,
                 RowCom, MPI_STATUS_IGNORE);

    }

    if (up_rank != MPI_PROC_NULL) {
        temp_send_up = new double[Nx_local];
        temp_recv_up = new double[Nx_local];

        #pragma omp parallel for default(shared) private(i) schedule(guided)
        for (i = 0; i < Nx_local; i++) {
            temp_send_up[i] = in[IDX(i, Ny_local-1)];
        }

        MPI_Sendrecv(temp_send_up, Nx_local, MPI_DOUBLE, up_rank, 0,
                 temp_recv_up, Nx_local, MPI_DOUBLE, up_rank, 0,
                 ColCom, MPI_STATUS_IGNORE);

    }

    if (down_rank != MPI_PROC_NULL) {
        temp_send_down = new double[Nx_local];
        temp_recv_down = new double[Nx_local];

        #pragma omp parallel for default(shared) private(i) schedule(guided)
        for (i = 0; i < Nx_local; i++) {
            temp_send_down[i] = in[IDX(i, 0)];
        }

        MPI_Sendrecv(temp_send_down, Nx_local, MPI_DOUBLE, down_rank, 0,
                 temp_recv_down, Nx_local, MPI_DOUBLE, down_rank, 0,
                 ColCom, MPI_STATUS_IGNORE);

    }

    //Helpful constants
    double dx2i = 1.0/dx/dx;
    double dy2i = 1.0/dy/dy;
    
    //Interior index limits (miss out edges) 
    int start_i = coords[1] == 0 ? 1 : 0;      //Left edge
    int end_i = Nx_local - (coords[1] == tot_cols - 1 ? 1 : 0); //Right edge
    
    int start_j = coords[0] == tot_rows - 1 ? 1 : 0;   //Bottom edge 
    int end_j = Ny_local - (coords[0] == 0 ? 1 : 0);  //Top edge
    
    omp_set_max_active_levels(2);
    
    int left, right, top, bottom;
    double in_left, in_right, in_top, in_bottom;
    
    //Constants - Profiler Stage
    double dx2iCF = 2.0*dx2i;
    double dy2iCF = 2.0*dy2i;
    
    #pragma omp parallel for collapse(2) \
    default(shared) private(i, j, left, right, top, bottom, in_left, in_right, in_top, in_bottom) \
    schedule(guided)
    for (j = start_j; j < end_j; j++) {
        for (i = start_i; i < end_i; i++) {
            //See if adjacent points are out of bounds, if so IDX(x,y) assigned -1
            
            left = i > 0 ? IDX(i-1, j) : -1;
            right = i < Nx_local - 1 ? IDX(i+1, j) : -1;
            top = j < Ny_local - 1 ? IDX(i, j+1) : -1;
            bottom = j > 0 ? IDX(i, j-1) : -1;
            
            //If adjacent points out of bounds, then data sent across boundary used
            
            in_left = (left != -1) ? in[left] : temp_recv_left[j];
            in_right = (right != -1) ? in[right] : temp_recv_right[j];
            
            in_top = (top != -1) ? in[top] : temp_recv_up[i];
            in_bottom = (bottom != -1) ? in[bottom] : temp_recv_down[i];
            
            //Compute apply operator
            out[IDX(i,j)] = ( -     in_left
                              -     in_right)*dx2i + dx2iCF*in[IDX(i,   j)]
                          + ( -     in_bottom
                              -     in_top)*dy2i + dy2iCF*in[IDX(i,   j)];

        }
    }
    
    delete[] temp_send_left;
    delete[] temp_send_right;
    delete[] temp_send_up;
    delete[] temp_send_down;
    
    delete[] temp_recv_left;
    delete[] temp_recv_right;
    delete[] temp_recv_up;
    delete[] temp_recv_down;
    
}

//Reduce ratio of max Eigenvalue / min Eigenvalue
void SolverCG::Precondition(double* in, double* out) {
    
    int Nx_local = Nx;
    int Ny_local = Ny;
    
    int i,j;
    
    //Fetches info about the cartesian grid
    int dims[2], periods[2], coords[2];
    MPI_Cart_get(CompleteDomain,2,dims,periods,coords);
    
    int tot_rows = dims[0];
    int tot_cols = dims[1];
    
    int start_i = 0, end_i = Nx_local;
    int start_j = 0, end_j = Ny_local;
    
     
    if (coords[1] == 0) {start_i = 1;} //Left edge
    if (coords[1] == tot_cols-1) {end_i = Nx_local -1;} //Right edge
    if (coords[0] == tot_rows-1) { start_j = 0; } //Bottom edge
    if (coords[0] == 0) { end_j = Ny_local - 1;}  //Top edge

    double dx2i = 1.0/dx/dx;
    double dy2i = 1.0/dy/dy;
    double factor = 2.0*(dx2i + dy2i);
    factor = 1.0/factor;
    
    omp_set_max_active_levels(2);
    
    //Precondition inner points
    #pragma omp parallel for collapse(2) default(shared) private(i, j) schedule(guided) 
    for (j = start_j; j < end_j; j++) {
        for (i = start_i; i < end_i; i++) {
            out[IDX(i,j)] = in[IDX(i,j)]*factor;
        }
    }
    
    //Keep boundary conditions the same
     if (coords[0] == 0) { // Top boundary of the global domain
        #pragma omp parallel for default(shared) private(i) schedule(guided) 
        for (i = 0; i < Nx_local; i++) {
            out[IDX(i, Ny_local-1)] = in[IDX(i, Ny_local-1)]; // Keep top boundary the same
        }
    }
    
    if (coords[0] == tot_rows - 1) { // Bottom boundary of the global domain
        #pragma omp parallel for default(shared) private(i) schedule(guided)
        for (i = 0; i < Nx_local; i++) {
            out[IDX(i, 0)] = in[IDX(i,0)]; // Keep bottom boundary the same
        }
    }

    // Left and right columns
    if (coords[1] == 0) { // Left boundary of the global domain
        #pragma omp parallel for default(shared) private(j) schedule(guided) 
        for (j = 0; j < Ny_local; j++) {
            out[IDX(0, j)] = in[IDX(0, j)]; // Keep left boundary the same
        }
    }
    
    if (coords[1] == tot_cols - 1) { // Right boundary of the global domain
        #pragma omp parallel for default(shared) private(j) schedule(guided)
        for (j = 0; j < Ny_local; j++) {
            out[IDX(Nx_local - 1, j)] = in[IDX(Nx_local - 1, j)]; // Keep right boundary the same
        }
    }
    

    
}

void SolverCG::ImposeBC(double* inout) {
    
    int Nx_local = Nx;
    int Ny_local = Ny;
    
    int i,j;
    
    // Boundaries
    
    //Fetches info about the cartesian grid
    int dims[2], periods[2], coords[2];
    MPI_Cart_get(CompleteDomain,2,dims,periods,coords);
    
    int tot_rows = dims[0];
    int tot_cols = dims[1];
    
    if (coords[0] == 0) { // Top boundary of the global domain
        #pragma omp parallel for default(shared) private(i) schedule(guided) 
        for (i = 0; i < Nx_local; i++) {
            inout[IDX(i, Ny_local-1)] = 0.0;
        }
    }
    
    if (coords[0] == tot_rows - 1) { // Bottom boundary of the global domain
        #pragma omp parallel for default(shared) private(i) schedule(guided) 
        for (i = 0; i < Nx_local; i++) {
            inout[IDX(i, 0)] = 0.0;
        }
    }

    // Left and right columns
    if (coords[1] == 0) { // Left boundary of the global domain
        #pragma omp parallel for default(shared) private(j) schedule(guided) 
        for (j = 0; j < Ny_local; j++) {
            inout[IDX(0, j)] = 0.0; // Keep left boundary the same
        }
    }
    if (coords[1] == tot_cols - 1) { // Right boundary of the global domain
        #pragma omp parallel for default(shared) private(j) schedule(guided) 
        for (j = 0; j < Ny_local; j++) {
            inout[IDX(Nx_local - 1, j)] = 0.0;
        }
    }
    
}
